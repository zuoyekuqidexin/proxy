# proxy

apt install -y curl && curl -L https://raw.githubusercontent.com/zuoyekuqidexin/proxy/main/i.sh | bash
